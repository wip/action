# Contributors

### Checkin

- Do check in source (src)
- Do not check in build output (lib)
- Do not check in node_modules
